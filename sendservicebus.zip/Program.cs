﻿using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;
using SendServiceBusQue.Model;
using System;
using System.Text;
using System.Threading.Tasks;

namespace SendServiceBusQue
{
    class Program
    {
        // connection string to your Service Bus namespace
        static string connectionString = "";

        // name of your Service Bus topic
        static string queueName = "";

        static async Task Main(string[] args)
        {
            Message msg = new Message();
            Data _data = new Data
            {
                process_code = "PRIC_SETTLEMENT_FWD",
                process_id = "PRIC_SETTLEMENT_FWD_20210827_0800",
                planned_date = System.DateTime.UtcNow.ToString(),
                attempt_number = 1
            };

            Root _Root = new Root()
            {
                specversion = "1.O",
                type = "pricer.context.plannedtask",
                source = "pricer.context",
                id = "context_plannedtask_20210827_12485432",
                time = System.DateTime.UtcNow.ToString(),
                datacontenttype = "application/json",
                data = _data
            };

            var queueClient = new QueueClient(connectionString, queueName);
            string JsonString = JsonConvert.SerializeObject(_Root);
            byte[] bytearray = Encoding.ASCII.GetBytes(JsonString);
            msg.ContentType = "application/json";
            msg.Body = bytearray;


            await queueClient.SendAsync(msg);
            Console.WriteLine(" message is Sent");
            Console.ReadKey();
        }

    }
}
