﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SendServiceBusQue.Model
{
    public class Root
    {
        public string specversion { get; set; }
        public string type { get; set; }
        public string source { get; set; }
        public string subject { get; set; }
        public string id { get; set; }
        public string time { get; set; }
        public string datacontenttype { get; set; }
        public Data data { get; set; }
    }

    public class Data
    {
        public string process_code { get; set; }
        public string process_id { get; set; }
        public string planned_date { get; set; }
        public int attempt_number { get; set; }
    }
}
